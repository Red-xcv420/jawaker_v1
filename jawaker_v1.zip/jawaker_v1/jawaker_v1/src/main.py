"""
Automate Gift Sending - Landen Fisher - 2/6/2024

Site: https://www.jawaker.com/en/competitions/tarneeb
"""

from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.common.by import By
from selenium import webdriver
import time, os



gift_id_here = "gift_id"

user_name = "your_username"



MAIN_DIR = os.path.dirname(os.path.abspath(__file__))

WebDriverPath = MAIN_DIR + '/src/driver/chromedriver.exe'

LogPath = MAIN_DIR + '/logs/web_driver.log'

profile = webdriver.FirefoxProfile()

options = Options()

driver = webdriver.Firefox(profile, options=options, executable_path=WebDriverPath, service_log_path=LogPath)

# Navigate to the Jawaker website
driver.get("https://www.jawaker.com/en/competitions/tarneeb")

cookies = [

    {

        'name': '_jawaker_session',

        'value': 'cookie',

        'domain': '.jawaker.com',

        'path': '/',

        'secure': True,

    },

]

driver.delete_all_cookies()

for cookie in cookies:

    driver.execute_script(
        f"document.cookie = '{cookie['name']}={cookie['value']}; domain={cookie['domain']}; path={cookie['path']}; secure={cookie['secure']}';"
    )

cookies = [

    {

        'name': 'locale',

        'value': 'en',

        'domain': '.jawaker.com',

        'path': '/',

        'secure': False,

    },

]

for cookie in cookies:

    driver.execute_script(
        f"document.cookie = '{cookie['name']}={cookie['value']}; domain={cookie['domain']}; path={cookie['path']}; secure={cookie['secure']}';"
    )

def main():

    driver.refresh()

    driver.get("https://www.jawaker.com/en/competitions/tarneeb")

    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '/html/body/div[3]/div[2]/a'))).click()

    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '/html/body/div[4]/div[5]/div[2]/div[1]/div[2]/div[2]/div[2]/div[1]/input'))).send_keys(user_name)

    counter = 0

    for i in range(10000):

        counter += 1

        user = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '/html/body/div[4]/div[5]/div[2]/div[1]/div[2]/div[2]/div[2]/div[2]/ul[3]/li[' + str(counter) +  ']/div/strong'))).text

        print(user)

        if user == user_name:

            WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '/html/body/div[4]/div[5]/div[2]/div[1]/div[2]/div[2]/div[2]/div[2]/ul[3]/li[' + str(counter) + ']'))).click()

            dev_xpath = '/html/body/div[4]/div[5]/div[2]/div[1]/div[2]/div[2]/div[2]/div[2]/ul[3]/li[' + str(counter) + ']'

            print(dev_xpath)

            break

    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '/html/body/div[6]/div/div[2]/div/div[2]/div[2]/div[2]/a[4]'))).click()

    counter_two = -1

    # test for more than one gift

    try:

        for i in range(500):

            counter_two += 1

            print(counter_two)

            gift_id = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '/html/body/div[6]/div[2]/div[2]/form/div/div/div/div/a[' + str(counter_two) + ']'))).get_attribute('data-record-id')

            print(gift_id)

            if gift_id == gift_id_here:

                WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '/html/body/div[6]/div[2]/div[2]/form/div/div/div/div/a[' + str(counter_two) + ']/div'))).click()

                time.sleep(500)

                driver.quit()
    
    except:

        pass

    # test for single gift
            
    for i in range(500):

        counter_two += 1

        print(counter_two)

        gift_id = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '/html/body/div[6]/div[2]/div[2]/form/div/div/div/div/a'))).get_attribute('data-record-id')

        print(gift_id)

        if gift_id == gift_id_here:

            WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '/html/body/div[6]/div[2]/div[2]/form/div/div/div/div/a/div'))).click()

            time.sleep(500)

            driver.quit()

    print("user not found or input left blank")

main()